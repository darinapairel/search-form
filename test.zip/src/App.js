import React, { useEffect, useState } from 'react'
import {connect} from 'react-redux'
import './App.css';
import SearchResult from './SearchResult'
import {getItems} from './app/actions'


function App(props) {

  const [subject, setSubject] = useState("")
  // useEffect( () => {
  //   fetch(url)
  // }. [])
  return (
    <div className="App">
      <header className="App-header">
        <h1>Search</h1>
      </header>

      <form className="App-form">
            <input type="text" name="search" id="search" value={subject} onChange={(event)=>{const val = event.target.value; setSubject(val); props.getItems(val)}}/>
            <button type="submit" id="search-icon-button" />
        </form>

       {/* {props.items.map( (item, index) => <SearchResult key={index} item={item}/>) }  Promise.all( */}

    </div>
  );
}

const mapStateToProps = store =>{
  console.log(store.items)
   return {
       store: store,
       value: store.value,
       items: store.items
   }
}
const mapDispatchToProps = dispatch =>{
  return{
      getItems: (val) => dispatch(getItems(val)),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(App)
