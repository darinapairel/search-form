import React from "react"


const SearchResult = (props) => {

    return(
        <article>
            <a href={props.item.html_url}>
                <h1>{props.item.full_name}</h1>
            </a>

            <p>Watchers: {props.item.watchers_count}</p>
            <p>Stars: {props.item.stargazers_count}</p>

        </article>
    )
}
export default SearchResult