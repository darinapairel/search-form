import React from "react"
import {connect} from 'react-redux'
import {search} from './app/actions'


// import {search} from './app/actions'

const SearchForm = (props) => {

    return(
        <form className="App-form">
            <input type="text" name="search" id="search" value={props.subject} onChange={(event)=>{search(event.target.value)}}/>
            <button type="submit" id="search-icon-button" />
        </form>
    )    
    //НАДО СДЕЛАТЬ ТАК, ЧТОБ ОБНОВЛЕНИЕ СОДЕРЖИМОГО ИНПУТА ДОБАВЛЯЛОСЬ В STORE ПОСЛЕ onChange
}

export default SearchForm