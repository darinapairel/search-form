import React from "react"
import SearchResult from './SearchResult'
import {connect} from 'react-redux'

const SearchList = (props) => {

    // const url = props.url
    // const getData = () => {
    //     setData(fetch(url)
    //         .then( response => response.json() )
    //         .then(json => json.items)
    //     )
    // }

    return(
        props.items.map( (item, index) => <SearchResult key={index} item={item}/>)
    )
}

const mapStateToProps = store => {
    console.log(store)
    return {
        items: store.items
    }
}
// const mapDispatchToProps = dispatch => {
//     return {
//         getData: data => dispatch(type:'CHANGE_SEARCH', payload:  )
//     }
// }
export default connect(
    mapStateToProps
)(SearchList)