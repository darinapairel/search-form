import {CHANGE_SEARCH, GET_ITEMS} from './types'

const initialState = {
    value:'',
    url:'', 
    items:[{full_name:'', html_url:'', watchers_count:0, stargazers_count:0}]
}

function fetchItems (url, state) {
    const items = fetch(url)
                    .then(data => data.json())
                    .then(json => json.items)
                    .then (items => items.map(item => {return {
                        full_name: item.full_name,
                        html_url: item.html_url,
                        watchers_count: item.watchers_count,
                        stargazers_count: item.stargazers_count
                    }}))
                    .then(items=> state={...state, url, items:items})
    //console.log('state fetch', state)

    return {state, items, url}
}

export default function reducer(state=initialState, action){
    switch(action.type) {
        case CHANGE_SEARCH:{
            const {value} = action.preloader
            
            return {...state, value}
        }
        case GET_ITEMS:{
            
            const value = action.preloader
            const url = `https://api.github.com/search/repositories?q=${value}`
            fetchItems(url, state)
            console.log('state after fetch', state)

            return {...state}
        }
        default: return state
    }
}