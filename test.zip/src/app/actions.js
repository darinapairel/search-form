import {CHANGE_SEARCH, GET_ITEMS} from './types'

export function search(value) {
    return {type: CHANGE_SEARCH, preloader: value}
}
export function getItems(value){
    return {type: GET_ITEMS, preloader: value}
}


// export const GET_ITEMS = "GET_ITEMS"

// export function getItems(items) {
//     return {type: GET_ITEMS, items}  
// }